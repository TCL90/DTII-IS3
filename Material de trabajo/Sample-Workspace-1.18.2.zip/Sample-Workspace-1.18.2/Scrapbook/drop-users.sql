drop user 'acme-user'@'%';

drop user 'acme-manager'@'%';

